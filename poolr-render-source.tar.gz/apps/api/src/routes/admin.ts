import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma.js';
import { requireAdmin, requireAuth } from '../middleware/auth.js';
import { AppError, asyncHandler } from '../utils/errors.js';
import { pagination } from '../utils/selects.js';

const router = Router();
router.use(requireAuth, requireAdmin);

router.get('/stats', asyncHandler(async (_req, res) => {
  const [users, rides, completed, bookings, reports, rating] = await Promise.all([
    prisma.user.count(), prisma.ride.count(), prisma.ride.count({ where: { status: 'COMPLETED' } }), prisma.booking.aggregate({ where: { status: { in: ['ACCEPTED', 'COMPLETED'] } }, _sum: { seats: true } }), prisma.report.count({ where: { status: { in: ['OPEN', 'REVIEWING'] } } }), prisma.review.aggregate({ where: { removedAt: null }, _avg: { rating: true } })
  ]);
  res.json({ data: { users, rides, completedRides: completed, seatsShared: bookings._sum.seats ?? 0, openReports: reports, averageRating: rating._avg.rating ?? 0 } });
}));

router.get('/users', asyncHandler(async (req, res) => {
  const page = pagination(req.query.page); const pageSize = pagination(req.query.pageSize, 25, 50);
  const [items, total] = await Promise.all([
    prisma.user.findMany({ orderBy: { createdAt: 'desc' }, skip: (page - 1) * pageSize, take: pageSize, select: { id: true, email: true, role: true, suspendedAt: true, createdAt: true, profile: true, _count: { select: { rides: true, bookings: true, reportsAgainst: true } } } }),
    prisma.user.count()
  ]);
  res.json({ data: items, meta: { page, pageSize, total } });
}));

router.post('/users/:id/suspension', asyncHandler(async (req, res) => {
  const { suspended } = z.object({ suspended: z.boolean() }).parse(req.body);
  if (req.params.id === req.user!.id) throw new AppError(422, 'SELF_MODERATION', 'You cannot suspend your own account.');
  const user = await prisma.user.update({ where: { id: req.params.id }, data: { suspendedAt: suspended ? new Date() : null }, select: { id: true, suspendedAt: true } });
  await prisma.auditLog.create({ data: { actorId: req.user!.id, action: suspended ? 'USER_SUSPENDED' : 'USER_REINSTATED', targetType: 'USER', targetId: user.id } });
  res.json({ data: user });
}));

router.get('/reports', asyncHandler(async (req, res) => {
  const page = pagination(req.query.page); const pageSize = pagination(req.query.pageSize, 25, 50);
  const [items, total] = await Promise.all([
    prisma.report.findMany({ orderBy: { createdAt: 'desc' }, skip: (page - 1) * pageSize, take: pageSize, include: { reporter: { select: { profile: true } }, targetUser: { select: { profile: true } }, ride: true, review: true, message: true } }),
    prisma.report.count()
  ]);
  res.json({ data: items, meta: { page, pageSize, total } });
}));

router.post('/reports/:id/status', asyncHandler(async (req, res) => {
  const { status } = z.object({ status: z.enum(['OPEN', 'REVIEWING', 'RESOLVED', 'DISMISSED']) }).parse(req.body);
  const report = await prisma.report.update({ where: { id: req.params.id }, data: { status } });
  await prisma.auditLog.create({ data: { actorId: req.user!.id, action: 'REPORT_STATUS_CHANGED', targetType: 'REPORT', targetId: report.id, metadata: { status } } });
  res.json({ data: report });
}));

router.post('/reviews/:id/remove', asyncHandler(async (req, res) => {
  const review = await prisma.review.update({ where: { id: req.params.id }, data: { removedAt: new Date() } });
  await prisma.auditLog.create({ data: { actorId: req.user!.id, action: 'REVIEW_REMOVED', targetType: 'REVIEW', targetId: review.id } });
  res.json({ data: review });
}));

router.post('/rides/:id/remove', asyncHandler(async (req, res) => {
  const ride = await prisma.ride.update({ where: { id: req.params.id }, data: { status: 'CANCELLED', cancelledAt: new Date() } });
  await prisma.auditLog.create({ data: { actorId: req.user!.id, action: 'RIDE_REMOVED', targetType: 'RIDE', targetId: ride.id } });
  res.json({ data: ride });
}));

export default router;
