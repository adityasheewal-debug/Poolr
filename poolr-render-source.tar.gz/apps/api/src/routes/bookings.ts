import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma.js';
import { requireAuth } from '../middleware/auth.js';
import { createBooking, decideBooking, cancelBooking } from '../services/booking-service.js';
import { AppError, asyncHandler } from '../utils/errors.js';
import { rideInclude } from '../utils/selects.js';

const router = Router();
router.use(requireAuth);

router.get('/', asyncHandler(async (req, res) => {
  const scope = req.query.scope === 'driver' ? 'driver' : 'passenger';
  const where = scope === 'driver' ? { ride: { driverId: req.user!.id } } : { passengerId: req.user!.id };
  const bookings = await prisma.booking.findMany({
    where, orderBy: { createdAt: 'desc' }, take: 50,
    include: { ride: { include: rideInclude }, passenger: { select: { id: true, profile: true } } }
  });
  res.json({ data: bookings });
}));

router.post('/', asyncHandler(async (req, res) => {
  const { rideId, seats } = z.object({ rideId: z.string().min(10), seats: z.number().int().min(1).max(8) }).parse(req.body);
  const key = req.header('idempotency-key');
  if (!key || key.length < 12 || key.length > 120) throw new AppError(400, 'IDEMPOTENCY_KEY_REQUIRED', 'A valid idempotency key is required.');
  res.status(201).json({ data: await createBooking(req.user!.id, rideId, seats, key) });
}));

router.post('/:id/accept', asyncHandler(async (req, res) => res.json({ data: await decideBooking(req.user!.id, req.params.id!, 'accept') })));
router.post('/:id/reject', asyncHandler(async (req, res) => res.json({ data: await decideBooking(req.user!.id, req.params.id!, 'reject') })));
router.post('/:id/cancel', asyncHandler(async (req, res) => res.json({ data: await cancelBooking(req.user!.id, req.params.id!) })));

export default router;
