import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';
import { prisma } from '../src/config/prisma.js';

const enabled = Boolean(process.env.TEST_DATABASE_URL);

describe.skipIf(!enabled)('complete carpool journey', () => {
  const stamp = Date.now();
  const driver = request.agent(app); const passenger = request.agent(app);
  let rideId = ''; let bookingId = ''; let conversationId = '';

  beforeAll(async () => {
    process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
    await prisma.$connect();
  });
  afterAll(async () => { await prisma.$disconnect(); });

  it('registers, offers, books, accepts, chats, completes, and reviews', async () => {
    await driver.post('/api/auth/register').send({ email: `driver-${stamp}@poolr.test`, password: 'PoolrTest1!', fullName: 'Test Driver', username: `driver_${stamp}`, timezone: 'UTC' }).expect(201);
    await passenger.post('/api/auth/register').send({ email: `rider-${stamp}@poolr.test`, password: 'PoolrTest1!', fullName: 'Test Rider', username: `rider_${stamp}`, timezone: 'UTC' }).expect(201);
    const vehicle = await driver.post('/api/profiles/vehicles').send({ name: 'Test Car', model: 'X', color: 'Blue', registrationNumber: `T${stamp}`, seatCapacity: 2 }).expect(201);
    const start = new Date(Date.now() + 86400000); const end = new Date(start.valueOf() + 3600000);
    const ride = await driver.post('/api/rides').send({ originName: 'Origin Gate', originCity: 'Delhi', destinationName: 'Destination Gate', destinationCity: 'Noida', departureAt: start.toISOString(), arrivalAt: end.toISOString(), seatsTotal: 2, priceMinor: 15000, currency: 'INR', vehicleId: vehicle.body.data.id, instantBooking: false, amenities: ['AC'], stops: [] }).expect(201);
    rideId = ride.body.data.id;
    const booking = await passenger.post('/api/bookings').set('idempotency-key', `journey-${stamp}`).send({ rideId, seats: 1 }).expect(201); bookingId = booking.body.data.id;
    await driver.post(`/api/bookings/${bookingId}/accept`).expect(200);
    const conversations = await passenger.get('/api/conversations').expect(200); conversationId = conversations.body.data[0].id;
    await passenger.post(`/api/conversations/${conversationId}/messages`).send({ body: 'I will be at the gate five minutes early.' }).expect(201);
    await prisma.ride.update({ where: { id: rideId }, data: { status: 'IN_PROGRESS' } });
    await driver.post(`/api/rides/${rideId}/status`).send({ status: 'COMPLETED' }).expect(200);
    await passenger.post('/api/reviews').send({ bookingId, rating: 5, body: 'Clear communication and a smooth ride.' }).expect(201);
    const saved = await prisma.review.findFirst({ where: { bookingId } });
    expect(saved?.rating).toBe(5);
  });
});
