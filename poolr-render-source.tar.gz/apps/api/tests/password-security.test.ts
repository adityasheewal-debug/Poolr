import { describe, expect, it } from 'vitest';
import bcrypt from 'bcryptjs';

describe('credential storage', () => {
  it('stores a one-way password hash rather than plaintext', async () => {
    const password = 'PoolrTest1!';
    const hash = await bcrypt.hash(password, 4);
    expect(hash).not.toContain(password);
    expect(await bcrypt.compare(password, hash)).toBe(true);
  });
});
