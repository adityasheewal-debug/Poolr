import { AnimatePresence, motion } from 'framer-motion';
import { Bell, Home, LogOut, Menu, MessageCircle, Moon, Plus, Route, Search, Settings, Shield, Sun, UserRound, X } from 'lucide-react';
import { useEffect, useState, type ReactNode } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth';
import { Avatar } from './ui';

const nav = [
  { to: '/app', label: 'Home', icon: Home }, { to: '/app/search', label: 'Search', icon: Search },
  { to: '/app/offer', label: 'Offer ride', icon: Plus }, { to: '/app/trips', label: 'Trips', icon: Route },
  { to: '/app/messages', label: 'Messages', icon: MessageCircle }, { to: '/app/profile', label: 'Profile', icon: UserRound }
];

function Brand() { return <NavLink to="/app" className="brand" aria-label="POOLR home"><span className="brand-mark"><span /><span /></span><strong>POOLR</strong></NavLink>; }

export function PublicHeader() { const [theme, setTheme] = useTheme(); return <header className="public-header"><Brand /><nav><a href="#how">How it works</a><a href="#safety">Safety</a><a href="#faq">FAQ</a></nav><div className="header-actions"><button className="icon-button" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label="Toggle theme">{theme === 'dark' ? <Sun /> : <Moon />}</button><NavLink className="button button-ghost" to="/login">Log in</NavLink><NavLink className="button button-primary" to="/register">Join POOLR</NavLink></div></header>; }

export function AppShell({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth(); const navigate = useNavigate(); const location = useLocation(); const [menu, setMenu] = useState(false); const [profileOpen, setProfileOpen] = useState(false); const [theme, setTheme] = useTheme();
  useEffect(() => setMenu(false), [location.pathname]);
  const onLogout = async () => { await logout(); navigate('/'); };
  return <div className="app-layout">
    <header className="topbar"><Brand /><nav className="desktop-nav">{nav.slice(0, 5).map(({ to, label, icon: Icon }) => <NavLink key={to} to={to} end={to === '/app'}><Icon />{label}</NavLink>)}</nav><div className="top-actions"><button className="icon-button" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label="Toggle theme">{theme === 'dark' ? <Sun /> : <Moon />}</button><NavLink className="icon-button notification-button" to="/app/notifications" aria-label="Notifications"><Bell /></NavLink><button className="profile-trigger" onClick={() => setProfileOpen(!profileOpen)}><Avatar name={user?.profile.fullName ?? 'U'} src={user?.profile.avatarUrl} size="sm" /><span>{user?.profile.fullName.split(' ')[0]}</span></button><button className="mobile-menu icon-button" onClick={() => setMenu(!menu)}>{menu ? <X /> : <Menu />}</button></div>
      <AnimatePresence>{profileOpen && <motion.div className="profile-menu glass-card" initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}><NavLink to="/app/profile"><UserRound /> My profile</NavLink><NavLink to="/app/settings"><Settings /> Settings</NavLink><NavLink to="/app/safety"><Shield /> Safety center</NavLink>{user?.role === 'ADMIN' && <NavLink to="/app/admin"><Shield /> Admin</NavLink>}<button onClick={onLogout}><LogOut /> Sign out</button></motion.div>}</AnimatePresence>
    </header>
    <AnimatePresence>{menu && <motion.nav className="mobile-drawer glass-card" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>{nav.map(({ to, label, icon: Icon }) => <NavLink key={to} to={to} end={to === '/app'}><Icon />{label}</NavLink>)}</motion.nav>}</AnimatePresence>
    <motion.main className="app-main" key={location.pathname} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .24 }}>{children}</motion.main>
    <nav className="bottom-nav">{[nav[0], nav[1], nav[2], nav[3], nav[5]].map((item, index) => { const Icon = item!.icon; return <NavLink key={item!.to} to={item!.to} end={item!.to === '/app'} className={index === 2 ? 'add-action' : ''}><Icon /><span>{index === 2 ? 'Add ride' : item!.label}</span></NavLink>; })}</nav>
  </div>;
}

function useTheme(): [string, (value: string) => void] { const [theme, setThemeState] = useState(() => localStorage.getItem('poolr-theme') || (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark')); const setTheme = (value: string) => { setThemeState(value); localStorage.setItem('poolr-theme', value); document.documentElement.dataset.theme = value; }; useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]); return [theme, setTheme]; }
