import { PrismaClient, type RideStatus } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();
const people = [
  ['Aarav Mehta','aarav','aarav@poolr.app','Product designer who likes calm drives, punctual pickups, and good playlists.','ADMIN'],
  ['Mira Das','miradas','mira@poolr.app','Architect commuting between Noida and South Delhi. Light luggage, always.','USER'],
  ['Kabir Bedi','kabirb','kabir@poolr.app','Weekend cyclist and weekday software engineer. Happy to chat or ride quietly.','USER'],
  ['Anaya Rao','anayarao','anaya@poolr.app','Postgraduate student, early riser, and careful trip planner.','USER'],
  ['Rohan Khanna','rohank','rohan@poolr.app','Consultant driving into Gurugram three days a week.','USER'],
  ['Ishita Sen','ishitas','ishita@poolr.app','Researcher, podcast listener, and reliable co-passenger.','USER'],
  ['Dev Malhotra','devm','dev@poolr.app','Film editor with flexible hours and room for two passengers.','USER'],
  ['Naina Iyer','nainai','naina@poolr.app','Teacher commuting from Faridabad to central Delhi.','USER'],
  ['Arjun Suri','arjuns','arjun@poolr.app','Operations lead, clean car, practical route planning.','USER'],
  ['Zoya Mirza','zoyam','zoya@poolr.app','Writer who prefers women-only rides and clear pickup instructions.','USER']
] as const;
const routes = [
  ['Hauz Khas Metro','Delhi','Cyber Hub','Gurugram'], ['Sector 62','Noida','Connaught Place','Delhi'], ['Greenfield Colony','Faridabad','Lajpat Nagar','Delhi'],
  ['Golf Course Road','Gurugram','Sector 18','Noida'], ['Dwarka Sector 10','Delhi','Udyog Vihar','Gurugram'], ['Greater Kailash II','Delhi','Film City','Noida'],
  ['Nehru Place','Delhi','DLF Phase 3','Gurugram'], ['Sector 21C','Faridabad','Saket','Delhi'], ['Indirapuram','Ghaziabad','Barakhamba Road','Delhi']
] as const;

const at = (dayOffset: number, hour: number, minute = 0) => { const d = new Date(); d.setUTCDate(d.getUTCDate() + dayOffset); d.setUTCHours(hour, minute, 0, 0); return d; };

async function clear() {
  await prisma.auditLog.deleteMany(); await prisma.report.deleteMany(); await prisma.review.deleteMany(); await prisma.notification.deleteMany(); await prisma.message.deleteMany();
  await prisma.conversationParticipant.deleteMany(); await prisma.conversation.deleteMany(); await prisma.booking.deleteMany(); await prisma.rideStop.deleteMany(); await prisma.ride.deleteMany();
  await prisma.favorite.deleteMany(); await prisma.savedLocation.deleteMany(); await prisma.vehicle.deleteMany(); await prisma.passwordResetToken.deleteMany(); await prisma.profile.deleteMany(); await prisma.user.deleteMany();
}

async function main() {
  await clear();
  const passwordHash = await bcrypt.hash('PoolrDemo1!', 12);
  const users = [];
  for (let i = 0; i < people.length; i++) {
    const [fullName, username, email, bio, role] = people[i]!;
    users.push(await prisma.user.create({ data: { email, passwordHash, role, emailVerified: i < 7, profile: { create: { fullName, username, bio, timezone: 'Asia/Kolkata', verified: i < 6, genderPreference: i === 9 ? 'women-only' : null } }, savedLocations: { create: [{ label: 'Home', name: routes[i % routes.length]![0], city: routes[i % routes.length]![1] }, { label: 'Work', name: routes[i % routes.length]![2], city: routes[i % routes.length]![3] }] } } }));
  }

  const carNames = [['Honda City','VX','Pearl White'],['Hyundai Verna','SX','Midnight Black'],['Tata Nexon','Creative','Ocean Blue'],['Maruti Brezza','ZXi','Silver'],['Skoda Slavia','Style','Red'],['Kia Seltos','HTX','Grey']] as const;
  const vehicles = [];
  for (let i = 0; i < carNames.length; i++) { const [name, model, color] = carNames[i]!; vehicles.push(await prisma.vehicle.create({ data: { ownerId: users[i]!.id, name, model, color, registrationNumber: `DL${8+i}CAF${2300+i*37}`, seatCapacity: i % 3 === 0 ? 4 : 3 } })); }

  const rides = [];
  for (let i = 0; i < 18; i++) {
    const route = routes[i % routes.length]!; const completed = i >= 15; const day = completed ? -(i - 13) : 1 + Math.floor(i / 3); const depart = at(day, 2 + (i % 4) * 3, i % 2 ? 30 : 0); const arrive = new Date(depart.valueOf() + (55 + (i % 3) * 15) * 60000); const driverIndex = i % vehicles.length;
    const status: RideStatus = completed ? 'COMPLETED' : 'SCHEDULED';
    rides.push(await prisma.ride.create({ data: { driverId: users[driverIndex]!.id, vehicleId: vehicles[driverIndex]!.id, originName: route[0], originCity: route[1], destinationName: route[2], destinationCity: route[3], departureAt: depart, arrivalAt: arrive, seatsTotal: vehicles[driverIndex]!.seatCapacity, seatsAvailable: completed ? vehicles[driverIndex]!.seatCapacity - 1 : vehicles[driverIndex]!.seatCapacity - (i % 3 === 0 ? 1 : 0), priceMinor: 12000 + (i % 5) * 2500, currency: 'INR', instantBooking: i % 3 === 0, amenities: i % 4 === 0 ? ['AC','Luggage','Women only'] : i % 2 === 0 ? ['AC','Luggage','Music'] : ['AC','Good conversation'], notes: i % 2 === 0 ? 'Please arrive five minutes early. One cabin bag is comfortable.' : 'Pickup is at the main gate. Message me if you need help locating it.', status, stops: i % 4 === 0 ? { create: [{ name: 'Dhaula Kuan', city: 'Delhi', position: 0 }] } : undefined } }));
  }

  for (let i = 0; i < rides.length; i += 3) {
    const ride = rides[i]!; const passenger = users[(i + 3) % users.length]!; const completed = ride.status === 'COMPLETED';
    const booking = await prisma.booking.create({ data: { rideId: ride.id, passengerId: passenger.id, seats: 1, status: completed ? 'COMPLETED' : 'ACCEPTED', idempotencyKey: `seed-booking-${i}` } });
    const conversation = await prisma.conversation.create({ data: { rideId: ride.id, participants: { create: [{ userId: ride.driverId }, { userId: passenger.id }] }, messages: { create: [{ senderId: passenger.id, body: 'Hi! I will be at the pickup point five minutes early.', createdAt: new Date(ride.departureAt.valueOf() - 7200000) }, { senderId: ride.driverId, body: 'Perfect. I will message when I am near the main gate.', createdAt: new Date(ride.departureAt.valueOf() - 7000000) }] } } });
    void conversation;
    await prisma.notification.createMany({ data: [{ userId: passenger.id, type: completed ? 'REVIEW_REMINDER' : 'BOOKING_ACCEPTED', title: completed ? 'How was your ride?' : 'Your ride is confirmed', body: `${ride.originCity} to ${ride.destinationCity}`, data: { rideId: ride.id, bookingId: booking.id } }, { userId: ride.driverId, type: 'SYSTEM', title: completed ? 'Ride completed' : 'Passenger confirmed', body: `${passenger.email.split('@')[0]} is on this ride.`, data: { rideId: ride.id } }] });
    if (completed) {
      await prisma.review.createMany({ data: [{ bookingId: booking.id, reviewerId: passenger.id, revieweeId: ride.driverId, rating: 5, body: 'Punctual pickup, clean car, and very clear communication.' }, { bookingId: booking.id, reviewerId: ride.driverId, revieweeId: passenger.id, rating: 5, body: 'Friendly, on time, and easy to coordinate with.' }] });
    }
  }

  await prisma.notification.createMany({ data: users.map((user) => ({ userId: user.id, type: 'SYSTEM', title: 'Welcome to the refreshed POOLR', body: 'Your trusted shared-ride workspace is ready.', data: {} })) });
  console.log(`Seeded ${users.length} users, ${vehicles.length} vehicles, and ${rides.length} rides.`);
  console.log('Demo login: aarav@poolr.app / PoolrDemo1!');
}

main().catch((error) => { console.error(error); process.exitCode = 1; }).finally(() => prisma.$disconnect());
