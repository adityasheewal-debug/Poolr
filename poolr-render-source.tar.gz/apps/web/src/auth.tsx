import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { api } from './api';
import type { User } from './types';

type RegisterInput = { email: string; password: string; fullName: string; username: string; timezone: string };
type AuthValue = { user: User | null; loading: boolean; login: (email: string, password: string) => Promise<void>; register: (input: RegisterInput) => Promise<void>; logout: () => Promise<void>; refresh: () => Promise<void> };
const AuthContext = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const refresh = async () => {
    try { setUser(await api<User>('/auth/me')); } catch { setUser(null); } finally { setLoading(false); }
  };
  useEffect(() => { void refresh(); }, []);
  const value = useMemo<AuthValue>(() => ({ user, loading, refresh,
    login: async (email, password) => setUser(await api<User>('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) })),
    register: async (input) => setUser(await api<User>('/auth/register', { method: 'POST', body: JSON.stringify(input) })),
    logout: async () => { await api('/auth/logout', { method: 'POST' }); setUser(null); }
  }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used inside AuthProvider');
  return value;
};
