import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { createHash, randomBytes } from 'node:crypto';
import { z } from 'zod';
import { prisma } from '../config/prisma.js';
import { env } from '../config/env.js';
import { requireAuth, signToken } from '../middleware/auth.js';
import { AppError, asyncHandler } from '../utils/errors.js';

const router = Router();
const credentials = z.object({ email: z.email().transform((v) => v.toLowerCase()), password: z.string().min(8).max(72) });
const sessionSelect = {
  id: true, email: true, role: true, emailVerified: true, createdAt: true,
  profile: true, vehicles: true,
  _count: { select: { rides: true, bookings: true, reviewsReceived: true } }
} as const;

const setSession = (res: any, user: { id: string; role: 'USER' | 'ADMIN' }) => {
  res.cookie('poolr_session', signToken(user.id, user.role), {
    httpOnly: true, sameSite: 'lax', secure: env.NODE_ENV === 'production', maxAge: 7 * 24 * 60 * 60 * 1000, path: '/'
  });
};

router.post('/register', asyncHandler(async (req, res) => {
  const body = credentials.extend({
    fullName: z.string().trim().min(2).max(80),
    username: z.string().trim().regex(/^[a-zA-Z0-9_]{3,24}$/).transform((v) => v.toLowerCase()),
    timezone: z.string().max(60).default('UTC')
  }).parse(req.body);
  const passwordHash = await bcrypt.hash(body.password, 12);
  const user = await prisma.user.create({
    data: {
      email: body.email, passwordHash,
      profile: { create: { fullName: body.fullName, username: body.username, timezone: body.timezone } },
      notifications: { create: { type: 'SYSTEM', title: 'Welcome to POOLR', body: 'Your account is ready. Complete your profile and take your first shared ride.' } }
    },
    select: sessionSelect
  });
  setSession(res, user);
  res.status(201).json({ data: user });
}));

router.post('/login', asyncHandler(async (req, res) => {
  const body = credentials.parse(req.body);
  const found = await prisma.user.findUnique({ where: { email: body.email } });
  if (!found || !(await bcrypt.compare(body.password, found.passwordHash))) throw new AppError(401, 'INVALID_CREDENTIALS', 'Email or password is incorrect.');
  if (found.suspendedAt) throw new AppError(403, 'ACCOUNT_SUSPENDED', 'This account is suspended. Contact support if this seems wrong.');
  setSession(res, found);
  const user = await prisma.user.findUniqueOrThrow({ where: { id: found.id }, select: sessionSelect });
  res.json({ data: user });
}));

router.post('/logout', (_req, res) => {
  res.clearCookie('poolr_session', { path: '/' });
  res.status(204).send();
});

router.get('/me', requireAuth, asyncHandler(async (req, res) => {
  const user = await prisma.user.findUniqueOrThrow({ where: { id: req.user!.id }, select: sessionSelect });
  res.json({ data: user });
}));

router.post('/forgot-password', asyncHandler(async (req, res) => {
  const { email } = z.object({ email: z.email().transform((v) => v.toLowerCase()) }).parse(req.body);
  const user = await prisma.user.findUnique({ where: { email } });
  let developmentToken: string | undefined;
  if (user) {
    const token = randomBytes(32).toString('hex');
    await prisma.passwordResetToken.create({ data: { userId: user.id, tokenHash: createHash('sha256').update(token).digest('hex'), expiresAt: new Date(Date.now() + 30 * 60 * 1000) } });
    if (env.NODE_ENV === 'development' && !env.SMTP_URL) developmentToken = token;
  }
  res.json({ data: { message: 'If that account exists, reset instructions have been created.', developmentToken } });
}));

router.post('/reset-password', asyncHandler(async (req, res) => {
  const { token, password } = z.object({ token: z.string().min(32), password: z.string().min(8).max(72) }).parse(req.body);
  const tokenHash = createHash('sha256').update(token).digest('hex');
  const record = await prisma.passwordResetToken.findUnique({ where: { tokenHash } });
  if (!record || record.usedAt || record.expiresAt < new Date()) throw new AppError(400, 'INVALID_RESET_TOKEN', 'This reset link is invalid or has expired.');
  await prisma.$transaction([
    prisma.user.update({ where: { id: record.userId }, data: { passwordHash: await bcrypt.hash(password, 12) } }),
    prisma.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } })
  ]);
  res.json({ data: { message: 'Password updated. You can now sign in.' } });
}));

router.patch('/email', requireAuth, asyncHandler(async (req, res) => {
  const { email, password } = z.object({ email: z.email().transform((v) => v.toLowerCase()), password: z.string().min(8).max(72) }).parse(req.body);
  const user = await prisma.user.findUniqueOrThrow({ where: { id: req.user!.id } });
  if (!(await bcrypt.compare(password, user.passwordHash))) throw new AppError(401, 'INVALID_PASSWORD', 'Your current password is incorrect.');
  const updated = await prisma.user.update({ where: { id: user.id }, data: { email, emailVerified: false }, select: { id: true, email: true } });
  res.json({ data: updated });
}));

router.patch('/password', requireAuth, asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = z.object({ currentPassword: z.string().min(8).max(72), newPassword: z.string().min(8).max(72) }).parse(req.body);
  const user = await prisma.user.findUniqueOrThrow({ where: { id: req.user!.id } });
  if (!(await bcrypt.compare(currentPassword, user.passwordHash))) throw new AppError(401, 'INVALID_PASSWORD', 'Your current password is incorrect.');
  if (await bcrypt.compare(newPassword, user.passwordHash)) throw new AppError(422, 'PASSWORD_REUSED', 'Choose a password you have not just used.');
  await prisma.user.update({ where: { id: user.id }, data: { passwordHash: await bcrypt.hash(newPassword, 12) } });
  res.json({ data: { message: 'Password updated.' } });
}));

router.delete('/account', requireAuth, asyncHandler(async (req, res) => {
  const { password } = z.object({ password: z.string().min(8).max(72) }).parse(req.body);
  const user = await prisma.user.findUniqueOrThrow({ where: { id: req.user!.id } });
  if (!(await bcrypt.compare(password, user.passwordHash))) throw new AppError(401, 'INVALID_PASSWORD', 'Your current password is incorrect.');
  await prisma.user.delete({ where: { id: user.id } });
  res.clearCookie('poolr_session', { path: '/' });
  res.status(204).send();
}));

export default router;
