import { Armchair, BadgeCheck, CarFront, Snowflake } from 'lucide-react';
import { Link } from 'react-router-dom';
import { money, timeOnly } from '../api';
import type { Ride } from '../types';
import { Avatar, Badge, GlassCard, Rating } from './ui';

export default function RideCard({ ride }: { ride: Ride }) {
  const name = ride.driver.profile.fullName;
  return <Link to={`/app/rides/${ride.id}`} aria-label={`${ride.originCity} to ${ride.destinationCity}`}>
    <GlassCard className="ride-card">
      <div>
        <div className="driver-line"><Avatar name={name} src={ride.driver.profile.avatarUrl} /><div><strong>{name} {ride.driver.profile.verified && <BadgeCheck size={14} className="inline text-emerald-400" />}</strong><small>{ride.driverRating ? <Rating value={ride.driverRating} count={ride.driverReviewCount} /> : 'New driver'}</small></div></div>
        <div className="ride-route"><div className="route-times"><span>{timeOnly(ride.departureAt)}</span><span>{timeOnly(ride.arrivalAt)}</span></div><div className="route-line"><span /><span /></div><div className="route-labels"><div><strong>{ride.originName}</strong><small>{ride.originCity}</small></div><div><strong>{ride.destinationName}</strong><small>{ride.destinationCity}</small></div></div></div>
        <div className="ride-meta"><Badge tone="accent"><Armchair size={12} /> {ride.seatsAvailable} seats</Badge>{ride.instantBooking && <Badge tone="success">Instant</Badge>}{ride.vehicle && <Badge><CarFront size={12} /> {ride.vehicle.name}</Badge>}{ride.amenities.includes('AC') && <Badge><Snowflake size={12} /> AC</Badge>}</div>
      </div>
      <div className="ride-price"><strong>{money(ride.priceMinor, ride.currency)}</strong><small>per seat</small></div>
    </GlassCard>
  </Link>;
}
