import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma.js';
import { requireAuth } from '../middleware/auth.js';
import { AppError, asyncHandler } from '../utils/errors.js';

const router = Router();
router.use(requireAuth);

router.post('/', asyncHandler(async (req, res) => {
  const body = z.object({
    type: z.enum(['USER', 'RIDE', 'REVIEW', 'MESSAGE']), reason: z.string().trim().min(3).max(120), details: z.string().trim().max(1500).optional(),
    targetUserId: z.string().optional(), rideId: z.string().optional(), reviewId: z.string().optional(), messageId: z.string().optional()
  }).parse(req.body);
  const target = { USER: body.targetUserId, RIDE: body.rideId, REVIEW: body.reviewId, MESSAGE: body.messageId }[body.type];
  if (!target) throw new AppError(422, 'REPORT_TARGET_REQUIRED', 'Choose what you are reporting.');
  if (body.targetUserId === req.user!.id) throw new AppError(422, 'SELF_REPORT', 'You cannot report your own account.');
  const report = await prisma.report.create({ data: { ...body, reporterId: req.user!.id } });
  res.status(201).json({ data: report });
}));

export default router;
