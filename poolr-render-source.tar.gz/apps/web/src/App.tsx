import { lazy, Suspense } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './auth';
import { AppShell } from './components/Shell';
import { Skeleton } from './components/ui';

const Landing = lazy(() => import('./pages/Landing'));
const AuthPage = lazy(() => import('./pages/AuthPage'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const SearchPage = lazy(() => import('./pages/SearchPage'));
const RideDetails = lazy(() => import('./pages/RideDetails'));
const OfferRide = lazy(() => import('./pages/OfferRide'));
const Trips = lazy(() => import('./pages/Trips'));
const Messages = lazy(() => import('./pages/Messages'));
const Profile = lazy(() => import('./pages/Profile'));
const Notifications = lazy(() => import('./pages/Notifications'));
const SettingsPage = lazy(() => import('./pages/SettingsPage'));
const Safety = lazy(() => import('./pages/Safety'));
const Admin = lazy(() => import('./pages/Admin'));
const NotFound = lazy(() => import('./pages/NotFound'));

function Protected({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="boot-loader"><Skeleton className="boot-mark" /><p>Preparing your journey…</p></div>;
  return user ? <AppShell>{children}</AppShell> : <Navigate to="/login" replace />;
}

export default function App() {
  return <Suspense fallback={<div className="boot-loader"><Skeleton className="boot-mark" /><p>Opening POOLR…</p></div>}><Routes>
    <Route path="/" element={<Landing />} /><Route path="/login" element={<AuthPage mode="login" />} /><Route path="/register" element={<AuthPage mode="register" />} />
    <Route path="/app" element={<Protected><Dashboard /></Protected>} /><Route path="/app/search" element={<Protected><SearchPage /></Protected>} /><Route path="/app/rides/:id" element={<Protected><RideDetails /></Protected>} />
    <Route path="/app/offer" element={<Protected><OfferRide /></Protected>} /><Route path="/app/trips" element={<Protected><Trips /></Protected>} /><Route path="/app/messages" element={<Protected><Messages /></Protected>} /><Route path="/app/messages/:id" element={<Protected><Messages /></Protected>} />
    <Route path="/app/profile" element={<Protected><Profile /></Protected>} /><Route path="/app/notifications" element={<Protected><Notifications /></Protected>} /><Route path="/app/settings" element={<Protected><SettingsPage /></Protected>} /><Route path="/app/safety" element={<Protected><Safety /></Protected>} /><Route path="/app/admin" element={<Protected><Admin /></Protected>} />
    <Route path="*" element={<NotFound />} />
  </Routes></Suspense>;
}
