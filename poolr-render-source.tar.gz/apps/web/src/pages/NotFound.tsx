import { ArrowLeft, Route } from 'lucide-react';
import { Link } from 'react-router-dom';
import { GlassCard } from '../components/ui';

export default function NotFound(){return <main className="boot-loader"><GlassCard className="empty-state max-w-lg"><span className="empty-icon"><Route/></span><span className="eyebrow">404 · Route not found</span><h1 className="text-4xl mt-3">This road goes nowhere.</h1><p>The page may have moved, or the link may be incomplete.</p><Link className="button button-primary" to="/"><ArrowLeft size={17}/> Back to POOLR</Link></GlassCard></main>}
