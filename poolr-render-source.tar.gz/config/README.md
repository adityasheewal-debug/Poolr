# POOLR configuration

Edit only `config/.env` for local setup. Both the React app and Express API load it automatically.

## Values you must configure

1. `DATABASE_URL`
   - Keep the provided value when using the included `docker-compose.yml`.
   - For Neon, Supabase, Railway, or another PostgreSQL host, paste its PostgreSQL connection URL.
2. `JWT_SECRET`
   - Generate a private secret from the repository root:
     `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
   - Paste the result between the quotes. Never expose it in frontend code or commit it.
3. `APP_URL`
   - Keep `http://localhost:5173` locally.
   - In production, use the exact public web origin, such as `https://poolr.example.com`.

No external API key is required for the core application. The map has a no-key fallback, chat persists using PostgreSQL, and POOLR does not process payments.

## Optional values

- `VITE_API_URL`: only when the frontend and backend use different public origins.
- `MAPBOX_TOKEN` and `SMTP_URL`: reserved for future richer map and email-provider integrations. Leave them commented out for the current build.

## After editing

From the repository root, run:

```powershell
npm install
docker compose up -d postgres
npm run db:deploy
npm run db:seed
npm run dev
```

Open `http://localhost:5173`.
