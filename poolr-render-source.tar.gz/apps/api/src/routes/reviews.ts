import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma.js';
import { requireAuth } from '../middleware/auth.js';
import { AppError, asyncHandler } from '../utils/errors.js';
import { pagination } from '../utils/selects.js';

const router = Router();

router.get('/user/:userId', asyncHandler(async (req, res) => {
  const page = pagination(req.query.page); const pageSize = pagination(req.query.pageSize, 10, 30);
  const where = { revieweeId: req.params.userId, removedAt: null };
  const [items, total, summary] = await Promise.all([
    prisma.review.findMany({ where, orderBy: { createdAt: 'desc' }, skip: (page - 1) * pageSize, take: pageSize, include: { reviewer: { select: { profile: true } }, booking: { select: { ride: { select: { originCity: true, destinationCity: true, departureAt: true } } } } } }),
    prisma.review.count({ where }),
    prisma.review.aggregate({ where, _avg: { rating: true } })
  ]);
  res.json({ data: items, meta: { page, pageSize, total, average: summary._avg.rating ?? 0 } });
}));

router.post('/', requireAuth, asyncHandler(async (req, res) => {
  const { bookingId, rating, body } = z.object({ bookingId: z.string().min(10), rating: z.number().int().min(1).max(5), body: z.string().trim().max(1000).optional() }).parse(req.body);
  const booking = await prisma.booking.findUnique({ where: { id: bookingId }, include: { ride: true } });
  if (!booking) throw new AppError(404, 'BOOKING_NOT_FOUND', 'Booking not found.');
  if (booking.status !== 'COMPLETED' || booking.ride.status !== 'COMPLETED') throw new AppError(409, 'RIDE_NOT_COMPLETED', 'Reviews are available after the ride is completed.');
  const isPassenger = booking.passengerId === req.user!.id; const isDriver = booking.ride.driverId === req.user!.id;
  if (!isPassenger && !isDriver) throw new AppError(403, 'FORBIDDEN', 'You were not part of this ride.');
  const revieweeId = isPassenger ? booking.ride.driverId : booking.passengerId;
  const review = await prisma.review.create({ data: { bookingId, reviewerId: req.user!.id, revieweeId, rating, body }, include: { reviewer: { select: { profile: true } } } });
  res.status(201).json({ data: review });
}));

export default router;
