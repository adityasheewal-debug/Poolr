import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma.js';
import { requireAuth } from '../middleware/auth.js';
import { AppError, asyncHandler } from '../utils/errors.js';
import { pagination } from '../utils/selects.js';

const router = Router();
router.use(requireAuth);

const assertParticipant = async (conversationId: string, userId: string) => {
  const participant = await prisma.conversationParticipant.findUnique({ where: { conversationId_userId: { conversationId, userId } } });
  if (!participant) throw new AppError(403, 'CONVERSATION_FORBIDDEN', 'You do not have access to this conversation.');
};

router.get('/', asyncHandler(async (req, res) => {
  const page = pagination(req.query.page); const pageSize = pagination(req.query.pageSize, 20, 50);
  const where = { participants: { some: { userId: req.user!.id } } };
  const [items, total] = await Promise.all([
    prisma.conversation.findMany({ where, orderBy: { updatedAt: 'desc' }, skip: (page - 1) * pageSize, take: pageSize, include: { ride: true, participants: { include: { user: { select: { id: true, profile: true } } } }, messages: { orderBy: { createdAt: 'desc' }, take: 1 } } }),
    prisma.conversation.count({ where })
  ]);
  res.json({ data: items, meta: { page, pageSize, total } });
}));

router.get('/:id/messages', asyncHandler(async (req, res) => {
  await assertParticipant(req.params.id!, req.user!.id);
  const page = pagination(req.query.page); const pageSize = pagination(req.query.pageSize, 40, 80);
  const items = await prisma.message.findMany({ where: { conversationId: req.params.id }, orderBy: { createdAt: 'desc' }, skip: (page - 1) * pageSize, take: pageSize, include: { sender: { select: { id: true, profile: true } } } });
  await prisma.conversationParticipant.update({ where: { conversationId_userId: { conversationId: req.params.id!, userId: req.user!.id } }, data: { lastReadAt: new Date() } });
  res.json({ data: items.reverse(), meta: { page, pageSize } });
}));

router.post('/:id/messages', asyncHandler(async (req, res) => {
  const { body } = z.object({ body: z.string().trim().min(1).max(2000) }).parse(req.body);
  await assertParticipant(req.params.id!, req.user!.id);
  const message = await prisma.$transaction(async (tx) => {
    const created = await tx.message.create({ data: { conversationId: req.params.id!, senderId: req.user!.id, body }, include: { sender: { select: { id: true, profile: true } } } });
    await tx.conversation.update({ where: { id: req.params.id }, data: { updatedAt: new Date() } });
    const others = await tx.conversationParticipant.findMany({ where: { conversationId: req.params.id, userId: { not: req.user!.id } } });
    if (others.length) await tx.notification.createMany({ data: others.map((p) => ({ userId: p.userId, type: 'NEW_MESSAGE', title: 'New message', body: body.length > 90 ? `${body.slice(0, 90)}…` : body, data: { conversationId: req.params.id } })) });
    return created;
  });
  res.status(201).json({ data: message });
}));

export default router;
