import type { ErrorRequestHandler, RequestHandler } from 'express';
import { randomUUID } from 'node:crypto';
import { Prisma } from '@prisma/client';
import { ZodError } from 'zod';

export class AppError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public fieldErrors?: Record<string, string[]>
  ) {
    super(message);
  }
}

export const asyncHandler = (fn: (...args: any[]) => Promise<any>): RequestHandler =>
  (req, res, next) => void fn(req, res, next).catch(next);

export const requestId: RequestHandler = (req, res, next) => {
  req.requestId = req.header('x-request-id') || randomUUID();
  res.setHeader('x-request-id', req.requestId);
  next();
};

export const notFound: RequestHandler = (req, _res, next) =>
  next(new AppError(404, 'NOT_FOUND', `No endpoint exists at ${req.method} ${req.path}.`));

export const errorHandler: ErrorRequestHandler = (error, req, res, _next) => {
  let appError = error instanceof AppError ? error : new AppError(500, 'INTERNAL_ERROR', 'Something went wrong. Please try again.');

  if (error instanceof ZodError) {
    const fields: Record<string, string[]> = {};
    for (const issue of error.issues) {
      const key = issue.path.join('.') || 'form';
      fields[key] = [...(fields[key] ?? []), issue.message];
    }
    appError = new AppError(422, 'VALIDATION_ERROR', 'Please check the highlighted fields.', fields);
  }

  if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
    appError = new AppError(409, 'DUPLICATE_RESOURCE', 'That value is already in use.');
  }

  if (appError.status >= 500) console.error(`[${req.requestId}]`, error);
  res.status(appError.status).json({
    error: {
      code: appError.code,
      message: appError.message,
      fieldErrors: appError.fieldErrors,
      requestId: req.requestId
    }
  });
};
