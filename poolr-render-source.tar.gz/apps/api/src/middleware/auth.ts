import type { RequestHandler } from 'express';
import jwt from 'jsonwebtoken';
import { prisma } from '../config/prisma.js';
import { env } from '../config/env.js';
import { AppError, asyncHandler } from '../utils/errors.js';

type TokenPayload = { sub: string; role: 'USER' | 'ADMIN' };

export const signToken = (id: string, role: 'USER' | 'ADMIN') =>
  jwt.sign({ sub: id, role }, env.JWT_SECRET, { expiresIn: '7d' });

export const requireAuth = asyncHandler(async (req, _res, next) => {
  const raw = req.cookies.poolr_session || req.header('authorization')?.replace(/^Bearer\s+/i, '');
  if (!raw) throw new AppError(401, 'AUTH_REQUIRED', 'Please sign in to continue.');
  try {
    const payload = jwt.verify(raw, env.JWT_SECRET) as TokenPayload;
    const user = await prisma.user.findUnique({ where: { id: payload.sub }, select: { id: true, role: true, suspendedAt: true } });
    if (!user || user.suspendedAt) throw new Error('inactive');
    req.user = { id: user.id, role: user.role };
    next();
  } catch {
    throw new AppError(401, 'SESSION_EXPIRED', 'Your session has expired. Please sign in again.');
  }
});

export const requireAdmin: RequestHandler = (req, _res, next) => {
  if (req.user?.role !== 'ADMIN') return next(new AppError(403, 'ADMIN_REQUIRED', 'You do not have permission to access this area.'));
  next();
};
