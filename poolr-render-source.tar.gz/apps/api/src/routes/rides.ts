import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma.js';
import { requireAuth } from '../middleware/auth.js';
import { AppError, asyncHandler } from '../utils/errors.js';
import { pagination, rideInclude } from '../utils/selects.js';

const router = Router();
const rideBody = z.object({
  originName: z.string().trim().min(2).max(100), originCity: z.string().trim().min(2).max(80),
  destinationName: z.string().trim().min(2).max(100), destinationCity: z.string().trim().min(2).max(80),
  departureAt: z.iso.datetime(), arrivalAt: z.iso.datetime(), seatsTotal: z.number().int().min(1).max(8),
  priceMinor: z.number().int().min(0).max(10000000), currency: z.string().length(3).transform((v) => v.toUpperCase()).default('INR'),
  vehicleId: z.string().nullable().optional(), instantBooking: z.boolean().default(false), amenities: z.array(z.string().max(40)).max(12).default([]), notes: z.string().max(500).optional(),
  stops: z.array(z.object({ name: z.string().min(2).max(100), city: z.string().min(2).max(80) })).max(6).default([])
});

router.get('/', asyncHandler(async (req, res) => {
  const page = pagination(req.query.page); const pageSize = pagination(req.query.pageSize, 12, 24);
  const date = typeof req.query.date === 'string' ? new Date(req.query.date) : undefined;
  const where: any = {
    status: 'SCHEDULED', departureAt: { gt: new Date(), ...(date && !Number.isNaN(date.valueOf()) ? { gte: date, lt: new Date(date.valueOf() + 86400000) } : {}) },
    ...(req.query.origin ? { originCity: { contains: String(req.query.origin), mode: 'insensitive' } } : {}),
    ...(req.query.destination ? { destinationCity: { contains: String(req.query.destination), mode: 'insensitive' } } : {}),
    ...(req.query.seats ? { seatsAvailable: { gte: pagination(req.query.seats, 1, 8) } } : {}),
    ...(req.query.instant === 'true' ? { instantBooking: true } : {})
  };
  const [items, total] = await Promise.all([
    prisma.ride.findMany({ where, include: rideInclude, orderBy: { departureAt: 'asc' }, skip: (page - 1) * pageSize, take: pageSize }),
    prisma.ride.count({ where })
  ]);
  res.json({ data: items, meta: { page, pageSize, total, pages: Math.ceil(total / pageSize) } });
}));

router.get('/mine', requireAuth, asyncHandler(async (req, res) => {
  const rides = await prisma.ride.findMany({ where: { driverId: req.user!.id }, include: { ...rideInclude, bookings: { include: { passenger: { select: { id: true, profile: true } } }, orderBy: { createdAt: 'desc' } } }, orderBy: { departureAt: 'desc' }, take: 50 });
  res.json({ data: rides });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const ride = await prisma.ride.findUnique({ where: { id: req.params.id }, include: rideInclude });
  if (!ride) throw new AppError(404, 'RIDE_NOT_FOUND', 'Ride not found.');
  const reviews = await prisma.review.findMany({ where: { revieweeId: ride.driverId, removedAt: null }, include: { reviewer: { select: { profile: true } } }, orderBy: { createdAt: 'desc' }, take: 5 });
  const rating = await prisma.review.aggregate({ where: { revieweeId: ride.driverId, removedAt: null }, _avg: { rating: true }, _count: true });
  res.json({ data: { ...ride, driverRating: rating._avg.rating ?? 0, driverReviewCount: rating._count, reviews } });
}));

router.post('/', requireAuth, asyncHandler(async (req, res) => {
  const body = rideBody.parse(req.body); const departureAt = new Date(body.departureAt); const arrivalAt = new Date(body.arrivalAt);
  if (departureAt <= new Date()) throw new AppError(422, 'PAST_DEPARTURE', 'Departure must be in the future.');
  if (arrivalAt <= departureAt) throw new AppError(422, 'INVALID_ARRIVAL', 'Arrival must be after departure.');
  if (body.vehicleId) {
    const vehicle = await prisma.vehicle.findFirst({ where: { id: body.vehicleId, ownerId: req.user!.id } });
    if (!vehicle) throw new AppError(422, 'INVALID_VEHICLE', 'Select one of your saved vehicles.');
    if (body.seatsTotal > vehicle.seatCapacity) throw new AppError(422, 'VEHICLE_CAPACITY', 'Seat count exceeds vehicle capacity.');
  }
  const { stops, ...data } = body;
  const ride = await prisma.ride.create({ data: { ...data, departureAt, arrivalAt, driverId: req.user!.id, seatsAvailable: body.seatsTotal, amenities: body.amenities, stops: { create: stops.map((stop, position) => ({ ...stop, position })) } }, include: rideInclude });
  res.status(201).json({ data: ride });
}));

router.patch('/:id', requireAuth, asyncHandler(async (req, res) => {
  const ride = await prisma.ride.findUnique({ where: { id: req.params.id }, include: { _count: { select: { bookings: { where: { status: 'ACCEPTED' } } } } } });
  if (!ride) throw new AppError(404, 'RIDE_NOT_FOUND', 'Ride not found.');
  if (ride.driverId !== req.user!.id) throw new AppError(403, 'FORBIDDEN', 'You cannot edit this ride.');
  if (ride.status !== 'SCHEDULED') throw new AppError(409, 'RIDE_LOCKED', 'An active or completed ride cannot be edited.');
  const body = rideBody.partial().omit({ stops: true }).parse(req.body);
  if (body.seatsTotal && body.seatsTotal < ride.seatsTotal - ride.seatsAvailable) throw new AppError(409, 'SEATS_CONFIRMED', 'Seat count cannot be lower than confirmed bookings.');
  const updated = await prisma.ride.update({ where: { id: ride.id }, data: { ...body, ...(body.departureAt ? { departureAt: new Date(body.departureAt) } : {}), ...(body.arrivalAt ? { arrivalAt: new Date(body.arrivalAt) } : {}), ...(body.seatsTotal ? { seatsAvailable: body.seatsTotal - (ride.seatsTotal - ride.seatsAvailable) } : {}) }, include: rideInclude });
  res.json({ data: updated });
}));

router.post('/:id/cancel', requireAuth, asyncHandler(async (req, res) => {
  const ride = await prisma.ride.findUnique({ where: { id: req.params.id } });
  if (!ride) throw new AppError(404, 'RIDE_NOT_FOUND', 'Ride not found.');
  if (ride.driverId !== req.user!.id) throw new AppError(403, 'FORBIDDEN', 'You cannot cancel this ride.');
  if (['COMPLETED', 'CANCELLED'].includes(ride.status)) throw new AppError(409, 'RIDE_INACTIVE', 'This ride is already closed.');
  const updated = await prisma.$transaction(async (tx) => {
    const bookings = await tx.booking.findMany({ where: { rideId: ride.id, status: { in: ['PENDING', 'ACCEPTED'] } } });
    await tx.booking.updateMany({ where: { id: { in: bookings.map((b) => b.id) } }, data: { status: 'CANCELLED', cancelledAt: new Date() } });
    if (bookings.length) await tx.notification.createMany({ data: bookings.map((b) => ({ userId: b.passengerId, type: 'BOOKING_CANCELLED', title: 'Ride cancelled', body: `${ride.originCity} to ${ride.destinationCity} was cancelled by the driver.`, data: { rideId: ride.id } })) });
    return tx.ride.update({ where: { id: ride.id }, data: { status: 'CANCELLED', cancelledAt: new Date(), seatsAvailable: ride.seatsTotal } });
  });
  res.json({ data: updated });
}));

router.post('/:id/status', requireAuth, asyncHandler(async (req, res) => {
  const { status } = z.object({ status: z.enum(['DRIVER_EN_ROUTE', 'ARRIVED', 'IN_PROGRESS', 'COMPLETED']) }).parse(req.body);
  const ride = await prisma.ride.findUnique({ where: { id: req.params.id } });
  if (!ride) throw new AppError(404, 'RIDE_NOT_FOUND', 'Ride not found.');
  if (ride.driverId !== req.user!.id) throw new AppError(403, 'FORBIDDEN', 'Only the driver can update ride status.');
  const allowed: Record<string, string> = { SCHEDULED: 'DRIVER_EN_ROUTE', DRIVER_EN_ROUTE: 'ARRIVED', ARRIVED: 'IN_PROGRESS', IN_PROGRESS: 'COMPLETED' };
  if (allowed[ride.status] !== status) throw new AppError(409, 'INVALID_RIDE_TRANSITION', 'That ride status change is not allowed.');
  const updated = await prisma.$transaction(async (tx) => {
    const result = await tx.ride.update({ where: { id: ride.id }, data: { status } });
    if (status === 'COMPLETED') {
      const bookings = await tx.booking.findMany({ where: { rideId: ride.id, status: 'ACCEPTED' } });
      await tx.booking.updateMany({ where: { id: { in: bookings.map((b) => b.id) } }, data: { status: 'COMPLETED' } });
      if (bookings.length) await tx.notification.createMany({ data: bookings.map((b) => ({ userId: b.passengerId, type: 'REVIEW_REMINDER', title: 'How was your ride?', body: 'Share a rating to help the POOLR community.', data: { bookingId: b.id, rideId: ride.id } })) });
    }
    return result;
  });
  res.json({ data: updated });
}));

export default router;
