# POOLR currently uses only Android platform WebView APIs.
