import type { Prisma } from '@prisma/client';
import { prisma } from '../config/prisma.js';
import { AppError } from '../utils/errors.js';

export const reserveSeats = async (tx: Prisma.TransactionClient, rideId: string, seats: number) => {
  const reserved = await tx.ride.updateMany({
    where: { id: rideId, status: 'SCHEDULED', seatsAvailable: { gte: seats } },
    data: { seatsAvailable: { decrement: seats }, version: { increment: 1 } }
  });
  if (!reserved.count) throw new AppError(409, 'SEATS_UNAVAILABLE', 'Those seats are no longer available. Try fewer seats or another ride.');
};

export async function createBooking(passengerId: string, rideId: string, seats: number, idempotencyKey: string) {
  const replay = await prisma.booking.findUnique({ where: { idempotencyKey }, include: { ride: true } });
  if (replay) {
    if (replay.passengerId !== passengerId) throw new AppError(409, 'IDEMPOTENCY_CONFLICT', 'This request key has already been used.');
    return replay;
  }

  return prisma.$transaction(async (tx) => {
    const ride = await tx.ride.findUnique({ where: { id: rideId } });
    if (!ride || ride.status !== 'SCHEDULED' || ride.departureAt <= new Date()) throw new AppError(409, 'RIDE_UNAVAILABLE', 'This ride is no longer available.');
    if (ride.driverId === passengerId) throw new AppError(422, 'OWN_RIDE', 'You cannot book your own ride.');
    const duplicate = await tx.booking.findFirst({ where: { rideId, passengerId, status: { in: ['PENDING', 'ACCEPTED'] } } });
    if (duplicate) throw new AppError(409, 'DUPLICATE_BOOKING', 'You already have an active request for this ride.');

    const status = ride.instantBooking ? 'ACCEPTED' : 'PENDING';
    if (status === 'ACCEPTED') await reserveSeats(tx, rideId, seats);
    const booking = await tx.booking.create({ data: { rideId, passengerId, seats, status, idempotencyKey }, include: { ride: true } });
    await tx.conversation.create({
      data: { rideId, participants: { create: [{ userId: ride.driverId }, { userId: passengerId }] } }
    });
    await tx.notification.createMany({ data: [
      { userId: ride.driverId, type: 'BOOKING_REQUESTED', title: status === 'ACCEPTED' ? 'New instant booking' : 'New ride request', body: `${seats} seat${seats > 1 ? 's' : ''} requested for ${ride.originCity} to ${ride.destinationCity}.`, data: { bookingId: booking.id, rideId } },
      { userId: passengerId, type: status === 'ACCEPTED' ? 'BOOKING_ACCEPTED' : 'SYSTEM', title: status === 'ACCEPTED' ? 'Ride booked' : 'Request sent', body: status === 'ACCEPTED' ? 'Your seat is confirmed.' : 'The driver will review your request.', data: { bookingId: booking.id, rideId } }
    ] });
    return booking;
  }, { isolationLevel: 'Serializable' });
}

export async function decideBooking(driverId: string, bookingId: string, action: 'accept' | 'reject') {
  return prisma.$transaction(async (tx) => {
    const booking = await tx.booking.findUnique({ where: { id: bookingId }, include: { ride: true } });
    if (!booking) throw new AppError(404, 'BOOKING_NOT_FOUND', 'Booking request not found.');
    if (booking.ride.driverId !== driverId) throw new AppError(403, 'FORBIDDEN', 'Only the driver can decide this request.');
    if (booking.status !== 'PENDING') throw new AppError(409, 'BOOKING_ALREADY_DECIDED', 'This request has already been handled.');
    if (action === 'accept') await reserveSeats(tx, booking.rideId, booking.seats);
    const updated = await tx.booking.update({ where: { id: booking.id }, data: { status: action === 'accept' ? 'ACCEPTED' : 'REJECTED' }, include: { ride: true, passenger: { select: { profile: true } } } });
    await tx.notification.create({ data: { userId: booking.passengerId, type: action === 'accept' ? 'BOOKING_ACCEPTED' : 'BOOKING_REJECTED', title: action === 'accept' ? 'Your ride is confirmed' : 'Ride request declined', body: `${booking.ride.originCity} to ${booking.ride.destinationCity}`, data: { bookingId, rideId: booking.rideId } } });
    return updated;
  }, { isolationLevel: 'Serializable' });
}

export async function cancelBooking(actorId: string, bookingId: string) {
  return prisma.$transaction(async (tx) => {
    const booking = await tx.booking.findUnique({ where: { id: bookingId }, include: { ride: true } });
    if (!booking) throw new AppError(404, 'BOOKING_NOT_FOUND', 'Booking not found.');
    if (booking.passengerId !== actorId) throw new AppError(403, 'FORBIDDEN', 'You cannot cancel this booking.');
    if (!['PENDING', 'ACCEPTED'].includes(booking.status)) throw new AppError(409, 'BOOKING_INACTIVE', 'This booking can no longer be cancelled.');
    if (booking.status === 'ACCEPTED') await tx.ride.update({ where: { id: booking.rideId }, data: { seatsAvailable: { increment: booking.seats }, version: { increment: 1 } } });
    const updated = await tx.booking.update({ where: { id: booking.id }, data: { status: 'CANCELLED', cancelledAt: new Date() } });
    await tx.notification.create({ data: { userId: booking.ride.driverId, type: 'BOOKING_CANCELLED', title: 'Passenger cancelled', body: `${booking.seats} seat${booking.seats > 1 ? 's are' : ' is'} available again.`, data: { bookingId, rideId: booking.rideId } } });
    return updated;
  }, { isolationLevel: 'Serializable' });
}
