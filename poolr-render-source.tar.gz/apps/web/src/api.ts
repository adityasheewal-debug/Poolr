const API_BASE = import.meta.env.VITE_API_URL ?? '';

export class ApiError extends Error {
  constructor(public code: string, message: string, public fieldErrors?: Record<string, string[]>) { super(message); }
}

export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE}/api${path}`, {
      ...options,
      credentials: 'include',
      headers: { ...(options.body ? { 'content-type': 'application/json' } : {}), ...options.headers }
    });
  } catch {
    throw new ApiError('NETWORK_ERROR', 'POOLR cannot reach the server. Check your connection and try again.');
  }
  if (response.status === 204) return undefined as T;
  const json = await response.json().catch(() => ({}));
  if (!response.ok) throw new ApiError(json.error?.code ?? 'REQUEST_FAILED', json.error?.message ?? 'Something went wrong.', json.error?.fieldErrors);
  return json.data as T;
}

export const money = (minor: number, currency = 'INR') => new Intl.NumberFormat('en-IN', { style: 'currency', currency, maximumFractionDigits: 0 }).format(minor / 100);
export const dateTime = (value: string, timezone?: string) => new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium', timeStyle: 'short', timeZone: timezone }).format(new Date(value));
export const timeOnly = (value: string) => new Intl.DateTimeFormat('en-IN', { hour: 'numeric', minute: '2-digit' }).format(new Date(value));
