process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? process.env.DATABASE_URL ?? 'postgresql://postgres:postgres@localhost:5432/poolr_test?schema=public';
process.env.JWT_SECRET ??= 'test-secret-that-is-definitely-more-than-thirty-two-characters';
process.env.APP_URL ??= 'http://localhost:5173';
process.env.NODE_ENV = 'test';

export default { test: { environment: 'node' } };
