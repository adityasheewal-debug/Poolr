export const publicProfileSelect = {
  id: true,
  emailVerified: true,
  createdAt: true,
  profile: { select: { fullName: true, username: true, bio: true, avatarUrl: true, verified: true } }
} as const;

export const rideInclude = {
  driver: { select: publicProfileSelect },
  vehicle: true,
  stops: { orderBy: { position: 'asc' as const } },
  _count: { select: { bookings: true } }
} as const;

export const pagination = (value: unknown, fallback = 1, maximum = 50) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(1, Math.min(maximum, Math.floor(parsed))) : fallback;
};
