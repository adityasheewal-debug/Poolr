import { config } from 'dotenv';
import path from 'node:path';
import { z } from 'zod';

// Root npm workspace commands run this package from apps/api.
// Load the single central configuration first, then allow apps/api/.env
// as a backwards-compatible fallback without overriding central values.
config({ path: path.resolve(process.cwd(), '../../config/.env') });
config();

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(4000),
  DATABASE_URL: z.string().min(1),
  JWT_SECRET: z.string().min(32),
  APP_URL: z.string().url().default('http://localhost:5173'),
  SMTP_URL: z.string().optional()
});

export const env = schema.parse(process.env);
