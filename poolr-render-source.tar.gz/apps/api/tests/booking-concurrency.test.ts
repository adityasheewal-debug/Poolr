import { describe, expect, it } from 'vitest';
import { reserveSeats } from '../src/services/booking-service.js';

describe('atomic seat inventory', () => {
  it('never accepts more seats than capacity under concurrent attempts', async () => {
    let seatsAvailable = 2;
    const tx = {
      ride: {
        updateMany: async ({ where }: any) => {
          await Promise.resolve();
          if (seatsAvailable < where.seatsAvailable.gte) return { count: 0 };
          seatsAvailable -= where.seatsAvailable.gte;
          return { count: 1 };
        }
      }
    } as any;

    const attempts = await Promise.allSettled([
      reserveSeats(tx, 'ride_opaque_1', 1),
      reserveSeats(tx, 'ride_opaque_1', 1),
      reserveSeats(tx, 'ride_opaque_1', 1)
    ]);

    expect(attempts.filter((a) => a.status === 'fulfilled')).toHaveLength(2);
    expect(attempts.filter((a) => a.status === 'rejected')).toHaveLength(1);
    expect(seatsAvailable).toBe(0);
  });
});
