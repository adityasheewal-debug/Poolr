import { Bell, CheckCheck, MessageCircle, Route } from 'lucide-react';
import { useEffect, useState } from 'react';
import { api, dateTime } from '../api';
import { Button, EmptyState, GlassCard } from '../components/ui';
import type { Notification } from '../types';

export default function Notifications() {
  const [items, setItems] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const load = () => { void api<Notification[]>('/notifications').then(setItems).finally(() => setLoading(false)); };
  useEffect(load, []);
  const read = async (id: string) => { await api(`/notifications/${id}/read`, { method: 'POST' }); setItems((value) => value.map((item) => item.id === id ? { ...item, readAt: new Date().toISOString() } : item)); };
  const all = async () => { await api('/notifications/read-all', { method: 'POST' }); setItems((value) => value.map((item) => ({ ...item, readAt: item.readAt ?? new Date().toISOString() }))); };

  const iconFor = (type: string) => type === 'NEW_MESSAGE' ? <MessageCircle /> : (type.includes('BOOKING') || type.includes('RIDE')) ? <Route /> : <Bell />;

  return <>
    <div className="page-head"><div><span className="eyebrow"><Bell size={14} /> Your activity</span><h1>Notifications.</h1><p>Ride decisions, messages, reminders, and reviews.</p></div>{items.some((item) => !item.readAt) && <Button variant="secondary" onClick={all}><CheckCheck size={16} /> Mark all read</Button>}</div>
    <GlassCard className="notification-list">
      {loading ? <div className="empty-state"><span className="spinner" /></div> : items.length ? items.map((item) => <div role="button" tabIndex={0} className={`notification-item ${item.readAt ? '' : 'unread'}`} key={item.id} onClick={() => { if (!item.readAt) void read(item.id); }} onKeyDown={(event) => { if (event.key === 'Enter' && !item.readAt) void read(item.id); }}><span className="notification-icon">{iconFor(item.type)}</span><div><strong>{item.title}</strong><p>{item.body}</p><small>{dateTime(item.createdAt)}</small></div>{!item.readAt && <span className="badge badge-accent ml-auto">New</span>}</div>) : <EmptyState icon={<Bell />} title="You’re all caught up." body="Booking updates and ride messages will appear here." />}
    </GlassCard>
  </>;
}
