import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../config/prisma.js';
import { requireAuth } from '../middleware/auth.js';
import { AppError, asyncHandler } from '../utils/errors.js';
import { publicProfileSelect } from '../utils/selects.js';

const router = Router();
router.use(requireAuth);

router.patch('/me', asyncHandler(async (req, res) => {
  const body = z.object({
    fullName: z.string().trim().min(2).max(80).optional(), username: z.string().trim().regex(/^[a-zA-Z0-9_]{3,24}$/).transform((v) => v.toLowerCase()).optional(),
    bio: z.string().trim().max(320).nullable().optional(), avatarUrl: z.url().nullable().optional(), phone: z.string().trim().max(24).nullable().optional(),
    genderPreference: z.string().max(40).nullable().optional(), timezone: z.string().max(60).optional(), profileVisibility: z.enum(['public', 'rides_only', 'private']).optional(),
    phoneVisibility: z.boolean().optional(), notifyBookings: z.boolean().optional(), notifyMessages: z.boolean().optional(), notifyReminders: z.boolean().optional()
  }).parse(req.body);
  const profile = await prisma.profile.update({ where: { userId: req.user!.id }, data: body });
  res.json({ data: profile });
}));

router.get('/vehicles', asyncHandler(async (req, res) => {
  res.json({ data: await prisma.vehicle.findMany({ where: { ownerId: req.user!.id }, orderBy: { createdAt: 'desc' } }) });
}));

router.post('/vehicles', asyncHandler(async (req, res) => {
  const body = z.object({ name: z.string().min(2).max(60), model: z.string().min(1).max(60), color: z.string().min(2).max(30), registrationNumber: z.string().min(4).max(20), seatCapacity: z.number().int().min(1).max(8), imageUrl: z.url().optional() }).parse(req.body);
  const vehicle = await prisma.vehicle.create({ data: { ...body, registrationNumber: body.registrationNumber.toUpperCase(), ownerId: req.user!.id } });
  res.status(201).json({ data: vehicle });
}));

router.patch('/vehicles/:id', asyncHandler(async (req, res) => {
  const existing = await prisma.vehicle.findUnique({ where: { id: req.params.id } });
  if (!existing) throw new AppError(404, 'VEHICLE_NOT_FOUND', 'Vehicle not found.');
  if (existing.ownerId !== req.user!.id) throw new AppError(403, 'FORBIDDEN', 'You cannot edit this vehicle.');
  const body = z.object({ name: z.string().min(2).max(60).optional(), model: z.string().min(1).max(60).optional(), color: z.string().min(2).max(30).optional(), registrationNumber: z.string().min(4).max(20).optional(), seatCapacity: z.number().int().min(1).max(8).optional(), imageUrl: z.url().nullable().optional() }).parse(req.body);
  res.json({ data: await prisma.vehicle.update({ where: { id: existing.id }, data: body }) });
}));

router.delete('/vehicles/:id', asyncHandler(async (req, res) => {
  const result = await prisma.vehicle.deleteMany({ where: { id: req.params.id, ownerId: req.user!.id } });
  if (!result.count) throw new AppError(404, 'VEHICLE_NOT_FOUND', 'Vehicle not found.');
  res.status(204).send();
}));

router.get('/locations', asyncHandler(async (req, res) => {
  res.json({ data: await prisma.savedLocation.findMany({ where: { userId: req.user!.id }, orderBy: { createdAt: 'desc' } }) });
}));

router.post('/locations', asyncHandler(async (req, res) => {
  const body = z.object({ label: z.string().min(1).max(30), name: z.string().min(2).max(100), city: z.string().min(2).max(80) }).parse(req.body);
  res.status(201).json({ data: await prisma.savedLocation.create({ data: { ...body, userId: req.user!.id } }) });
}));

router.delete('/locations/:id', asyncHandler(async (req, res) => {
  const result = await prisma.savedLocation.deleteMany({ where: { id: req.params.id, userId: req.user!.id } });
  if (!result.count) throw new AppError(404, 'LOCATION_NOT_FOUND', 'Saved location not found.');
  res.status(204).send();
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.params.id }, select: { ...publicProfileSelect, vehicles: { select: { id: true, name: true, model: true, color: true, seatCapacity: true, imageUrl: true } } } });
  if (!user) throw new AppError(404, 'USER_NOT_FOUND', 'Profile not found.');
  const [rating, completed] = await Promise.all([
    prisma.review.aggregate({ where: { revieweeId: user.id, removedAt: null }, _avg: { rating: true }, _count: true }),
    prisma.booking.count({ where: { passengerId: user.id, status: 'COMPLETED' } })
  ]);
  res.json({ data: { ...user, rating: rating._avg.rating ?? 0, reviewCount: rating._count, completedRides: completed } });
}));

export default router;
