# POOLR — Smart Carpool

POOLR is a production-oriented carpool web application for offering, discovering, booking, and coordinating shared rides. It pairs a premium liquid-glass React interface with an authorization-first Express API and PostgreSQL persistence.

## Highlights

- Secure email/password registration, login, logout, password reset, password/email changes, persistent HTTP-only sessions, and protected routes
- Personal profiles, privacy preferences, saved places, vehicle management, public driver profiles, and ratings
- Paginated ride search, filters, list/map fallback, route stops, six-step offer flow, editing, cancellation, and a driver state machine
- Transaction-safe seat acceptance and instant booking with serializable transactions, conditional inventory updates, and idempotency keys
- Driver/passenger trip dashboards, persistent conversations, message notifications, cancellation, and post-completion reviews
- Notification read state, safety reports, protected moderation, suspension/removal controls, and audit logging
- UTC timestamps, time-zone rendering, integer minor-unit money, opaque IDs, server-boundary validation, rate limits, CORS, Helmet, and stable API errors
- Responsive desktop/mobile navigation, light/dark appearance, reduced-motion support, skeletons, empty/error states, focus states, and PWA manifest

## Screenshots

Add deployment screenshots here after branding and demo-data review:

- `docs/screenshots/landing-desktop.png`
- `docs/screenshots/dashboard-desktop.png`
- `docs/screenshots/search-mobile.png`
- `docs/screenshots/trips-mobile.png`

## Stack

- Web: React 19, Vite 7, TypeScript, Tailwind CSS 4, Framer Motion, Lucide
- API: Node.js 20+, Express 5, TypeScript, Zod, JWT, bcryptjs
- Data: PostgreSQL 16, Prisma 6, checked-in SQL migration, realistic seed
- Quality: ESLint 9, Vitest, Supertest, strict TypeScript

## Repository structure

```text
apps/
  web/                 React application and design system
    public/            Manifest and install icon
    src/components/    Shell, ride cards, reusable UI
    src/pages/         Connected product pages
  api/
    prisma/            Schema, SQL migration, seed
    src/config/        Environment and database client
    src/middleware/    Authentication and authorization
    src/routes/        REST boundary grouped by resource
    src/services/      Transactional booking service
    src/utils/         Errors, pagination, safe selectors
    tests/             Concurrency, credential, and E2E journey tests
docker-compose.yml     Local PostgreSQL
```

## Requirements

- Node.js 20 or newer (Node 22 LTS recommended)
- npm 10 or newer
- PostgreSQL 15+; Docker Desktop is the easiest local option

## Install and run

```powershell
npm install
docker compose up -d postgres
# Edit config/.env and replace JWT_SECRET first.
npm run db:deploy
npm run db:seed
npm run dev
```

Open `http://localhost:5173`. The seed command prints the demo login; the default is:

```text
aarav@poolr.app
PoolrDemo1!
```

`npm run dev` starts both applications. Vite proxies `/api` to `http://localhost:4000`.

## Environment

All local values live in the single central file `config/.env`, which both applications load automatically:

| Variable | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | Yes | PostgreSQL connection URL |
| `JWT_SECRET` | Yes | At least 32 random characters for session signing |
| `APP_URL` | Yes | Allowed web origin, normally `http://localhost:5173` |
| `PORT` | No | API port, defaults to `4000` |
| `NODE_ENV` | No | `development`, `test`, or `production` |

Optional:

| Variable | Purpose and fallback |
| --- | --- |
| `SMTP_URL` | Password-reset email transport. Without it, development returns a reset token; production always returns a safe generic response. |
| `MAPBOX_TOKEN` | Reserved for a richer map provider. Without it, route search and booking stay functional with the styled map fallback. |
| `VITE_API_URL` | Only needed when the web app and API use different origins. Same-origin `/api` is the default. |

Never expose `DATABASE_URL`, `JWT_SECRET`, or an SMTP credential to browser code.

## Database

The initial migration is checked in at `apps/api/prisma/migrations/20260816000100_initial/migration.sql`.

```powershell
npm run db:generate       # regenerate Prisma client
npm run db:migrate        # create/apply migrations during development
npm run db:deploy         # apply checked-in migrations in production
npm run db:seed           # reset and add 10 people, 18 rides, chats, alerts, and reviews
npm run db:studio
```

The seed command intentionally clears POOLR tables. Do not run it against production data.

## Quality commands

```powershell
npm run typecheck
npm run lint
npm test
npm run build
```

The default test run covers password hashing and concurrent conditional seat reservation. The complete journey test is enabled when an isolated PostgreSQL URL is supplied:

```powershell
$env:TEST_DATABASE_URL = "postgresql://postgres:postgres@localhost:5432/poolr_test?schema=public"
$env:DATABASE_URL = $env:TEST_DATABASE_URL
npm run db:deploy
npm test
```

The E2E scenario covers register → vehicle → offer → request → accept → message → complete → review. Never point `TEST_DATABASE_URL` at production.

## Production

```powershell
npm install
npm run db:deploy
npm run build
$env:NODE_ENV = "production"
npm start
```

The Express server serves the built web application and API on `PORT`. Put it behind HTTPS and a trusted reverse proxy, use a managed PostgreSQL database, set a unique strong `JWT_SECRET`, and configure `APP_URL` to the public origin.

## API behavior

All errors follow this safe shape:

```json
{
  "error": {
    "code": "SEATS_UNAVAILABLE",
    "message": "Those seats are no longer available.",
    "fieldErrors": {},
    "requestId": "opaque-request-id"
  }
}
```

Retryable booking creation requires an `Idempotency-Key` header. Acceptance and cancellation run in serializable transactions; accepted inventory uses a conditional `seatsAvailable >= requestedSeats` update.

## Deployment options

- Single service: deploy the repository to Render, Railway, Fly.io, or a VM; run `npm run build`, then `npm start`.
- Split web/API: deploy `apps/web/dist` to a static host, deploy `apps/api` separately, set `VITE_API_URL`, and set `APP_URL` to the web origin before building.
- Database: Neon, Supabase PostgreSQL, Railway PostgreSQL, RDS, or any standard PostgreSQL 15+ instance.

## Graceful fallbacks and known limitations

- Chat is persistent and polls every five seconds; typing indicators and push delivery need a realtime provider.
- The map view is a deliberate no-key route fallback, not live turn-by-turn navigation.
- POOLR records a suggested ride contribution but does not process payments.
- The Safety Center does not contact or track emergency services. The India `112` link is an ordinary phone link.
- Password-reset email delivery requires SMTP. Development exposes a token only when SMTP is absent; production does not.
- Carbon figures shown in the dashboard are labelled estimates; production should calculate them from measured distance and documented vehicle assumptions.
- Email verification UI is represented by trust state, but outbound verification requires the same email-provider integration.

## Troubleshooting

- `P1001` or database unavailable: confirm PostgreSQL is running and `DATABASE_URL` uses the mapped port.
- CORS or missing cookies: `APP_URL` must exactly match the browser origin; use HTTPS in production.
- Migration conflict: run `npx prisma migrate status --schema apps/api/prisma/schema.prisma` and do not edit a migration already applied to shared environments.
- Port conflict: change `PORT` for the API and update the Vite proxy in development.
- Windows script issues: run commands in PowerShell and use the documented npm scripts; no Unix-only shell scripts are required.

## License

Private project. Replace this section with the chosen license before public distribution.
